const mongoose=require('mongoose');
mongoose.connect('mongodb+srv://tjbose8:tjbose8@cluster0.7rnfv.mongodb.net/test',(err)=>{if(err){console.log(err)}})
const Schema=mongoose.Schema

const ESchema=new Schema({

    
    id:String,
    identity:String,
    designation:String,
    mobno:String,
    salary:Number,
    info:String,
    createdDate:String,
    updatedDate:String,
    
});


var Edata=mongoose.model('Employees',ESchema)

module.exports=Edata;