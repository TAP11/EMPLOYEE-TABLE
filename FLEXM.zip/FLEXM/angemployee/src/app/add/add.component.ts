import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { empModel } from './emp.model';
import { EmpserviceService } from '../empservice.service';
import { DatePipe, formatDate } from '@angular/common';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css'],
  providers:[DatePipe]
})
export class AddComponent implements OnInit {
  Date
  constructor(private router :Router,private _e :EmpserviceService) { }

employee= new empModel(null,null,null,null,null,null,null,null)

ngOnInit(): void {}

add(){   this. Date=new Date(); 
          this.employee.createdDate=formatDate(this.Date,'dd-MM-yyyy','en-US')
           this._e.ADD(this.employee).subscribe((data)=>{console.log(data)})
            alert("Successfully Added"); console.log(this.employee)
               this.router.navigate([""])}


}
