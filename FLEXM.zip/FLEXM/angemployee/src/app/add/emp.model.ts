export class empModel{
    constructor(
        
        
    public id:String,
    public identity:String,
    public designation:String,
    public mobno:String,
    public salary:Number,
    public info:String,
    public createdDate:String,
    public updatedDate:String
    
        
    ){}

}
