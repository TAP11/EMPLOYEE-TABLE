import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angemployee';

  
  
  constructor( private router : Router){}

  HOME(){this.router.navigate(['']) }

  ADD(){this.router.navigate(['add']) }

  SEARCH(){this.router.navigate(['search']) }
}
