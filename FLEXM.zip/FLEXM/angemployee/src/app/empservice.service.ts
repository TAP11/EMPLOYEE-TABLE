import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class EmpserviceService {

  constructor(private http:HttpClient, private router : Router) { }

  UPLIST(ID)
  {return this.http.post("http://localhost:8000/api/uplist",{ID})}
  
  UP(ID,employee)
  {return this.http.patch("http://localhost:8000/api/update",{ID,employee})}


  DEL(ID)
  {return this.http.post("http://localhost:8000/api/delete",{ID})}

  ADD(employee)
  { 
    return this.http.post("http://localhost:8000/api/add",{employee})}
 
  READ()
  {return this.http.get("http://localhost:8000/api/read")}

  SEARCH(s){return this.http.post("http://localhost:8000/api/search",{s})}

}
