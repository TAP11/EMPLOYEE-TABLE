import { Component, OnInit } from '@angular/core';
import {EmpserviceService} from '../empservice.service';
import{empModel} from'../add/emp.model';
import {Router} from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  startdate;
  enddate;
   
  feeds : any ;

  constructor(public _e:EmpserviceService, private router: Router) { }

  ngOnInit():void { console.log(this.startdate)

    this._e.READ().subscribe((data)=>{
      console.log(data)
        this.feeds=JSON.parse(JSON.stringify(data))} )
      
  }

  del(id):void{   
    if(confirm("Confirm to delete")==true){
       this._e.DEL(id)
         .subscribe((data)=>{this.feeds=JSON.parse(JSON.stringify(data))})}}
      
      
      
}
