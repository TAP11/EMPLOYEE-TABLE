import { Component, OnInit } from '@angular/core';
import {EmpserviceService} from '../empservice.service';
import { NgxPaginationModule } from 'ngx-pagination';
import {Router} from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  s;
  feeds:any;
  totalRecords:string;
  page:any=1;
  constructor(public _e:EmpserviceService, private router: Router) { }

  ngOnInit(): void {}

  S(){ 
  this._e.SEARCH(this.s).subscribe((data)=>{
    this.feeds=JSON.parse(JSON.stringify(data))})
      this.totalRecords=this.feeds.length;
}

}
