export class empModel{
    constructor(
        
        
    id:String,
    identity:String,
    designation:String,
    mobno:String,
    salary:Number,
    info:String,
    createdDate:Date,
    updatedDate:Date
        
        
    ){}

}
