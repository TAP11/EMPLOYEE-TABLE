import { Component, OnInit } from '@angular/core';
import {empModel} from '../add/emp.model';
import { ActivatedRoute,Router } from '@angular/router';
import { EmpserviceService } from '../empservice.service';
import { DatePipe, formatDate } from '@angular/common';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  Date
  
  employee= new empModel(null,null,null,null,null,null,null,null,)
  constructor(private _route: ActivatedRoute,private router :Router,private _e:EmpserviceService) { }
  
  ngOnInit(): void {
    let id=this._route.snapshot.paramMap.get("id");
      const ID={id:id};
        this._e.UPLIST(ID)
          .subscribe((data)=>{this.employee=JSON.parse(JSON.stringify(data)); console.log(this.employee)})
  }
 
  UPDATE(){
    this. Date=new Date(); 
     let id=this._route.snapshot.paramMap.get("id");
        this.employee.updatedDate=formatDate(this.Date,'dd-MM-yyyy','en-US')
          const ID={id:id};
            this._e.UP(ID,this.employee).subscribe((data)=>{console.log(data);})
               alert('Successfully updated');
                 this.router.navigate([""])}
}
