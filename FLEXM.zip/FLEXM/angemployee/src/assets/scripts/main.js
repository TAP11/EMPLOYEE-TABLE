
$(document).ready (function(){$('#cdate').datepicker();
$('#udate').datepicker();})