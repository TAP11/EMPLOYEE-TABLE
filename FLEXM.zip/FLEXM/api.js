const express=require('express');
const router=express.Router();
const Edata=require('./BACKEND/models/employee');


router.get('/read',(req,res)=>{ 
   Edata.find((err)=>{if(err){console.log(err);}}).then((feeds)=>{res.send(feeds)});
  });

  router.post('/search',(req,res)=>{
     Edata.find({$or:[{"mobno":{$regex: new RegExp("^"+req.body.s+'$',"i")}},
         {"identity":{$regex: new RegExp("^"+req.body.s+'$',"i")}},
            {"info":{$regex: new RegExp("^"+req.body.s+'$',"i")}},
               {"createdDate":{$regex: new RegExp("^"+req.body.s+'$',"i")}}]})
                  .then((feeds)=>{res.send(feeds);})
   });

router.post('/uplist',(req,res)=>{ 
  Edata.findById({_id:req.body.ID.id}).then((feeds)=>{res.send(feeds)});
  });
  
router.post('/add', (req,res)=>{ 
 var employee={id:req.body.employee.id,
                 identity:req.body.employee.identity,
                   designation:req.body.employee.designation,
                      mobno:req.body.employee.mobno,
                       salary:req.body.employee.salary,
                         info:req.body.employee.info,
                           createdDate:req.body.employee.createdDate,
                             updatedDate:'Not Updated',}
                               var employee= new Edata(employee);
                                 employee.save();res.send(req.body)})


router.patch('/update',(req,res)=>{
  
 
    Edata.findOneAndUpdate({_id:req.body.ID.id},{ 
      id:req.body.employee.id,
        identity:req.body.employee.identity,
          designation:req.body.employee.designation,
            mobno:req.body.employee.mobno,
              salary:req.body.employee.salary,
                info:req.body.employee.info,
                  createdDate:req.body.employee.createdDate,
                    updatedDate:req.body.employee.updatedDate,
                     },(err)=>{if(err){console.log(err);}}); 
                        res.send(req.body);
                         });


router.post('/delete',(req,res)=>{
    
      Edata.findByIdAndDelete({_id:req.body.ID},(err)=>{if(err){console.log(err)}})
      .then(()=>{ Edata.find().then((data)=>{res.send(data);
         console.log("Deleted Item Successfully");})})})


 


module.exports=router;
